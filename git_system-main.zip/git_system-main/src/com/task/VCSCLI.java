package com.task;

import java.util.Scanner;

public class VCSCLI {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        VersionControlSystem vcs = new VersionControlSystem();
        vcs.init();

        while (true) {
            System.out.print("vcs> ");
            String command = scanner.nextLine();
            String[] commandParts = command.split(" ");
            String mainCommand = commandParts[0];

            switch (mainCommand) {
                case "init":
                    vcs.init();
                    System.out.println("Repository initialized.");
                    break;
                case "add":
                    if (commandParts[1].equals(".")) {
                        System.out.print("Enter number of files to add: ");
                        int numFiles = Integer.parseInt(scanner.nextLine());
                        for (int i = 0; i < numFiles; i++) {
                            System.out.print("Enter file path: ");
                            String filePath = scanner.nextLine();
                            System.out.print("Enter file content: ");
                            String content = scanner.nextLine();
                            vcs.add(filePath, content);
                        }
                        System.out.println("All files added.");
                    } else {
                        System.out.print("Enter file content: ");
                        String content = scanner.nextLine();
                        vcs.add(commandParts[1], content);
                        System.out.println("File added.");
                    }
                    break;
                case "commit":
                    String message = command.substring(command.indexOf(" ") + 1);
                    vcs.commit(message);
                    System.out.println("Changes committed.");
                    break;
                case "status":
                    vcs.status();
                    break;
                case "log":
                    vcs.log();
                    break;
                case "exit":
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Unknown command.");
                    break;
            }
        }
    }
}


