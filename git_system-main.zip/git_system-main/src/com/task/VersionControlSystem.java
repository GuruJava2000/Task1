package com.task;

import java.util.*;
import java.util.concurrent.locks.ReentrantReadWriteLock;

class File {
    private String name;
    private String content;

    public File(String name, String content) {
        this.name = name;
        this.content = content;
    }

    public String getName() {
        return name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}

class Folder {
    private String name;
    private Map<String, File> files;
    private Map<String, Folder> folders;

    public Folder(String name) {
        this.name = name;
        this.files = new HashMap<>();
        this.folders = new HashMap<>();
    }

    public String getName() {
        return name;
    }

    public Map<String, File> getFiles() {
        return files;
    }

    public Map<String, Folder> getFolders() {
        return folders;
    }
}

class Version {
    private String versionId;
    private Map<String, Folder> rootFolders;
    private String message;
    private String timestamp;

    public Version(String versionId, Map<String, Folder> rootFolders, String message) {
        this.versionId = versionId;
        this.rootFolders = new HashMap<>(rootFolders);
        this.message = message;
        this.timestamp = new Date().toString();
    }

    public String getVersionId() {
        return versionId;
    }

    public Map<String, Folder> getRootFolders() {
        return rootFolders;
    }

    public String getMessage() {
        return message;
    }

    public String getTimestamp() {
        return timestamp;
    }
}

public class VersionControlSystem {
    private Map<String, Version> versions;
    private ReentrantReadWriteLock lock;
    private Map<String, Folder> stagingArea;
    private Version currentVersion;

    public VersionControlSystem() {
        this.versions = new HashMap<>();
        this.lock = new ReentrantReadWriteLock();
        this.stagingArea = new HashMap<>();
    }

    // Initialize the repository
    public void init() {
        lock.writeLock().lock();
        try {
            stagingArea.put("root", new Folder("root"));
            currentVersion = new Version("initial", stagingArea, "Initial commit");
            versions.put("initial", currentVersion);
        } finally {
            lock.writeLock().unlock();
        }
    }

    // Add file to staging area
    public void add(String filePath, String content) {
        lock.writeLock().lock();
        try {
            String[] pathParts = filePath.split("/");
            Folder currentFolder = stagingArea.get("root");
            for (int i = 1; i < pathParts.length - 1; i++) {
                currentFolder = currentFolder.getFolders().computeIfAbsent(pathParts[i], k -> new Folder(k));
            }
            currentFolder.getFiles().put(pathParts[pathParts.length - 1], new File(pathParts[pathParts.length - 1], content));
        } finally {
            lock.writeLock().unlock();
        }
    }

    // Commit changes in the staging area
    public void commit(String message) {
        lock.writeLock().lock();
        try {
            String newVersionId = UUID.randomUUID().toString();
            Version newVersion = new Version(newVersionId, stagingArea, message);
            versions.put(newVersionId, newVersion);
            currentVersion = newVersion;
            // Reset staging area for new changes
            stagingArea = new HashMap<>();
            stagingArea.put("root", new Folder("root"));
        } finally {
            lock.writeLock().unlock();
        }
    }

    // Display files in the current version
    public void status() {
        lock.readLock().lock();
        try {
            displayFiles(currentVersion);
        } finally {
            lock.readLock().unlock();
        }
    }

    private void displayFiles(Version version) {
        System.out.println("Version: " + version.getVersionId() + " - " + version.getMessage());
        for (Folder folder : version.getRootFolders().values()) {
            displayFolder(folder, "");
        }
    }

    private void displayFolder(Folder folder, String indent) {
        System.out.println(indent + folder.getName() + "/");
        for (File file : folder.getFiles().values()) {
            System.out.println(indent + "  " + file.getName());
        }
        for (Folder subFolder : folder.getFolders().values()) {
            displayFolder(subFolder, indent + "  ");
        }
    }

    // Display log of all commits
    public void log() {
        lock.readLock().lock();
        try {
            for (Version version : versions.values()) {
                System.out.println(version.getTimestamp() + " - " + version.getVersionId() + ": " + version.getMessage());
            }
        } finally {
            lock.readLock().unlock();
        }
    }
}
