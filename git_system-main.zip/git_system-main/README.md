# git_system
vcs> init
Repository initialized.
vcs> add root/file1.txt
Enter file content: Hello World
File added.
vcs> add root/folder1/file2.txt
Enter file content: Hello Java
File added.
vcs> commit Initial commit
Changes committed.
vcs> status
Version: <UUID> - Initial commit
root/
  file1.txt
  folder1/
    file2.txt
vcs> add .
Enter number of files to add: 2
Enter file path: root/file3.txt
Enter file content: Hello VCS
Enter file path: root/folder2/file4.txt
Enter file content: Hello CLI
All files added.
vcs> commit Second commit
Changes committed.
vcs> log
<timestamp> - <UUID>: Initial commit
<timestamp> - <UUID>: Second commit
vcs> exit
Exiting...
